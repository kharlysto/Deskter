# Deskter — working local foundation

Run `python3 server.py` with Python 3.12+ and open http://127.0.0.1:8000.
No installation or external dependencies are required. SQLite is created automatically.
Set DESKTER_DB to choose another database location. Do not commit the database.

This implements the screenshot's light/purple dashboard direction, reconstructed geometric logo, original navigation sections, responsive layout, account registration/sign-in/sign-out, seller-owned listing creation/editing, discovery/search/category/price sorting, persistent saves/follows, customer inquiries, seller lead status updates, and database-backed activity counts.

The original uploaded Ethos source remains separate and unchanged. This is a new app, not a recovered version of the missing launchpad prototype. The logo is recreated from the screenshot; replace it with the original SVG when available.

## Verify

`python3 -m unittest discover -s tests -v`

Create a seller account, publish a listing, then use a separate browser profile to create a buyer. Send an inquiry, save the listing, and follow the seller. Return to the seller's Leads screen to respond by changing status. Reload to verify persistence.

## Current boundaries

This is a local development foundation, not a production-ready marketplace. It listens only on 127.0.0.1. It uses scrypt password hashing, opaque expiring HTTP-only sessions, SameSite cookies, origin checks, parameterized queries, escaped display content, and ownership checks. No real payment or email is sent. Account email is not verified; password reset, login throttling, abuse controls, production HTTPS/Secure cookies, moderation, backup operations and monitoring must precede public deployment. Profile editing, uploads, digital fulfillment, subscription billing, ads, payouts, verified reviews and messaging replies remain unimplemented. Admin Center is an informational placeholder, not an administrative permission.

Discover shows real published database records; an empty database has an actionable empty state. New assets default to private drafts. Set Visibility to Published in the asset editor to show them in Discover. Owners can edit, archive, or republish assets. Publishing means creating a marketplace listing; it does not deploy a hosted application or upload downloadable files. Production still needs a moderation policy.

Pricing supports one-time, monthly, yearly, starting-at, free, and request-a-quote displays in PHP. Amounts are stored as integer centavos. Recurring rates are labels only; billing is not connected. Quote-based listings are excluded from numeric maximum-price filters and placed last in low-price sorting. Authentication resumes interrupted creation, contact, save, and follow actions. Editing the profile updates the public seller display name.

Additional pricing checks: `node tests/pricing.cjs` (Node.js required for this optional test only).

## Before committing

Copy this folder's contents into a feature branch of the correct repository. Review and run the tests; do not overwrite unrelated repository work. Commit only source, documentation, and tests. No remote repository was connected or changed by this delivery.

## Next decisions

Choose launch categories and whether the first release is quote-first or checkout-first. This build implements quote-first. Decide seller review/verification rules, launch geography, payment provider eligibility, refund policy, and platform fees before commerce. Advertising needs a pricing and measurement contract; Pro needs a defined entitlement list. The older illustrative 8% and 20% rates are not implemented pricing.
