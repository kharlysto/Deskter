import http.cookiejar, json, os, tempfile, threading, unittest, urllib.request, urllib.error
from http.server import ThreadingHTTPServer
import server

class Workflow(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();server.DB=os.path.join(self.tmp.name,'test.sqlite3');server.init()
        self.http=ThreadingHTTPServer(('127.0.0.1',0),server.Handler)
        self.thread=threading.Thread(target=self.http.serve_forever,daemon=True);self.thread.start()
        self.base='http://127.0.0.1:'+str(self.http.server_port)+'/api/'
    def tearDown(self):
        self.http.shutdown();self.http.server_close();self.tmp.cleanup()
    def client(self):return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def req(self,client,path,data=None,method=None,origin=None):
        headers={'Content-Type':'application/json'}
        if origin:headers['Origin']=origin
        r=urllib.request.Request(self.base+path,data=None if data is None else json.dumps(data).encode(),headers=headers,method=method)
        try:
            with client.open(r) as response:return response.status,json.load(response)
        except urllib.error.HTTPError as e:return e.code,json.load(e)
    def register(self,c,email):
        self.assertEqual(self.req(c,'register',{'name':'Test Seller','email':email,'password':'secure-example-pass'})[0],200)
    def test_full_workflow_and_authorization(self):
        seller,buyer,anon=self.client(),self.client(),self.client()
        self.register(seller,'seller@example.test');self.register(buyer,'buyer@example.test')
        listing={'title':'Brand design','description':'A complete brand identity package','category':'Services','price':1250000}
        self.assertEqual(self.req(anon,'listings',listing)[0],401)
        self.assertEqual(self.req(seller,'listings',listing,origin='https://evil.test')[0],403)
        self.assertEqual(self.req(seller,'listings',listing)[0],200)
        state=self.req(seller,'state')[1];item=state['listings'][0]
        self.assertEqual(item['price'],1250000)
        self.assertEqual(self.req(buyer,'listings',{**listing,'id':item['id']})[0],403)
        self.assertEqual(self.req(buyer,'save',{'id':item['id']})[0],200)
        self.assertEqual(self.req(buyer,'follow',{'id':item['owner']})[0],200)
        self.assertEqual(self.req(buyer,'leads',{'id':item['id'],'message':'Please send a quote for my new business.'})[0],200)
        lead=self.req(seller,'state')[1]['leads'][0]
        self.assertEqual(self.req(buyer,'leads',{'id':lead['id'],'status':'Closed'},'PATCH')[0],403)
        self.assertEqual(self.req(seller,'leads',{'id':lead['id'],'status':'In progress'},'PATCH')[0],200)
        self.assertEqual(self.req(seller,'state')[1]['leads'][0]['status'],'In progress')
        self.assertEqual(self.req(buyer,'state')[1]['saved'],[item['id']])
        self.assertEqual(self.req(anon,'state')[1]['leads'],[])
        self.req(buyer,'logout',{})
        self.assertIsNone(self.req(buyer,'state')[1]['user'])
        self.assertEqual(self.req(buyer,'login',{'email':'buyer@example.test','password':'secure-example-pass'})[0],200)
        self.assertEqual(self.req(buyer,'state')[1]['following'],[item['owner']])
    def test_input_validation(self):
        c=self.client();self.register(c,'test@example.test')
        for price in [-1,1.25,True]:
            self.assertEqual(self.req(c,'listings',{'title':'Valid name','description':'Long enough description','category':'Services','price':price})[0],400)
        self.assertEqual(self.req(c,'login',{'email':'test@example.test','password':'wrong-password'})[0],401)
        self.assertEqual(self.req(c,'register',{'name':'Short','email':'x@example.test','password':'short'})[0],400)
    def test_draft_publish_archive_and_pricing(self):
        seller,buyer=self.client(),self.client()
        self.register(seller,'seller@example.test');self.register(buyer,'buyer@example.test')
        item={'title':'Precision pricing','description':'Includes a complete project consultation.','category':'Services','price':125050,'pricing':'monthly','status':'draft'}
        self.assertEqual(self.req(seller,'listings',item)[0],200)
        own=self.req(seller,'state')[1]['listings'][0];item['id']=own['id']
        self.assertEqual(own['price'],125050)
        self.assertEqual(own['status'],'draft')
        self.assertEqual(self.req(buyer,'state')[1]['listings'],[])
        self.assertEqual(self.req(buyer,'save',{'id':item['id']})[0],400)
        self.assertEqual(self.req(buyer,'leads',{'id':item['id'],'message':'Please send me a custom quote.'})[0],400)
        item['status']='published';self.assertEqual(self.req(seller,'listings',item)[0],200)
        self.assertEqual(self.req(buyer,'state')[1]['listings'][0]['pricing'],'monthly')
        for mode in ['one_time','monthly','yearly','starting_at','quote','free']:
            item['pricing']=mode
            self.assertEqual(self.req(seller,'listings',item)[0],200)
            result=self.req(buyer,'state')[1]['listings'][0]
            self.assertEqual(result['price'],0 if mode in ['quote','free'] else 125050)
        self.assertEqual(self.req(seller,'listings',{**item,'pricing':'weekly'})[0],400)
        self.assertEqual(self.req(seller,'listings',{**item,'pricing':'one_time','price':0})[0],400)
        self.assertEqual(self.req(buyer,'listings',{**item,'status':'archived'})[0],403)
        item['status']='archived';self.assertEqual(self.req(seller,'listings',item)[0],200)
        self.assertEqual(self.req(buyer,'state')[1]['listings'],[])
        self.assertEqual(self.req(seller,'state')[1]['listings'][0]['status'],'archived')
        self.assertEqual(self.req(seller,'profile',{'name':'Updated Seller'})[0],200)
        self.assertEqual(self.req(seller,'state')[1]['user']['name'],'Updated Seller')
    def test_upgrade_existing_database(self):
        with server.connect() as c:
            c.execute('DROP TABLE leads');c.execute('DROP TABLE saves');c.execute('DROP TABLE listings')
            c.execute('CREATE TABLE listings(id INTEGER PRIMARY KEY,owner INTEGER,title TEXT,category TEXT,description TEXT,price INTEGER,created INTEGER)')
            c.execute("INSERT INTO listings VALUES(1,1,'Legacy listing','Services','Existing description',1500,0)")
        server.init();server.init()
        with server.connect() as c:
            row=c.execute('SELECT * FROM listings WHERE id=1').fetchone()
            self.assertEqual(row['price'],1500);self.assertEqual(row['pricing'],'one_time');self.assertEqual(row['status'],'published')

if __name__=='__main__':unittest.main()
