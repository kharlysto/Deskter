# Publishing and pricing corrections

- Resume asset creation after authentication; resume save, follow, and inquiry intents too.
- Commit database mutations before sending success responses, preventing a subsequent reload from racing the database commit.
- Clear filters after saving so the new asset is visible in Assets.
- Add private drafts, publication, archival, republication, and an idempotent upgrade for existing databases.
- Enforce visibility and ownership on the server. Unpublished listings cannot receive new saves or inquiries.
- Add six explicit PHP pricing models, integer centavo conversion, validation, and price labels including billing intervals.
- Add profile display-name editing and reject self-following.
- Replace sample listings with real database records and useful empty states.
- Mark unavailable sidebar sections Soon and disable the Pro upgrade control.
- Improve card alignment, stable cover colors, long-description handling, modal layout, and submit progress feedback.
- Explain how to start the server when the HTML is opened directly.

Four backend test methods pass, covering existing-data migration, publication lifecycle, visibility, ownership, inquiries, account operations, and pricing validation. Frontend pricing and escaping tests pass. Full browser rendering and browser form interactions remain unverified because Chromium cannot launch under the environment's restrictions.

This is still not a production release. Hosted deployment, payments, uploads/fulfillment, email verification and recovery, login throttling, protected moderation, ad delivery, and Pro billing remain outstanding.
